# Whiteout Yardımcı — Android prototipi

Bu uygulama Whiteout Survival hesabına bağlanmaz, ekran görüntüsü okumaz ve oyun içinde otomatik dokunma/av yapmaz. Kaynak, inşaat, araştırma ve eğitim için hatırlatıcı sağlar.

## APK oluşturma
1. Bilgisayara Android Studio (güncel kararlı sürüm) kur.
2. Bu klasörü Android Studio'da `Open` ile aç.
3. Gradle senkronizasyonunun bitmesini bekle.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seç.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.
6. APK'yı telefona aktar ve aç. Android sorarsa yalnızca bu dosya yöneticisi için “bilinmeyen uygulama yükleme” iznini geçici olarak ver.
7. Uygulamayı açınca bildirim iznini kabul et. Tam saatli bildirim için Android'in “Alarmlar ve hatırlatıcılar” iznini de isteyebilir.

## Xiaomi / HyperOS notları
- Ayarlar > Uygulamalar > Uygulamaları yönet > Whiteout Yardımcı > Pil tasarrufu bölümünde arka plan çalışmasına izin ver (menü isimleri sürüme göre değişebilir).
- Bildirim iznini açık tut.
- HyperOS bazı arka plan işlemlerini erteleyebilir; kesin zaman garantisi yoktur.
- Bu uygulama oyun otomasyonu değil, yardımcı zamanlayıcı prototipidir.

## Bilinen sınırlar
- Hatırlatıcılar yerel olarak ayarlanır; yeniden başlatma sonrası alarmları yeniden kurma işlevi bu ilk prototipte yoktur.
- Uygulama görev sürelerini oyundan otomatik okuyamaz; süreyi kullanıcı girer.
- Ekran kapalıyken oyun içi görev başlatmaz ve kutup hayvanı avlamaz.
