package com.example.whiteouthelper

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("timers", Context.MODE_PRIVATE) }
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        createChannel()

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 32, 36, 32)
            setBackgroundColor(0xFFF4F6F3.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "Whiteout Yardımcı"
            textSize = 26f
            setTextColor(0xFF20352A.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Kaynak, inşaat, araştırma ve eğitim süreleri için hatırlatıcılar. Bu uygulama oyun hesabına bağlanmaz ve oyun içinde otomatik işlem yapmaz."
            textSize = 15f
            setPadding(0, 12, 0, 20)
        })

        val titleInput = EditText(this).apply {
            hint = "Hatırlatıcı adı (örn. Araştırma)"
            singleLine = true
        }
        root.addView(titleInput, matchWidth())

        val hours = EditText(this).apply {
            hint = "Kaç saat sonra? (örn. 8)"
            inputType = 2
            singleLine = true
        }
        root.addView(hours, matchWidth())

        val minutes = EditText(this).apply {
            hint = "Ek dakika (isteğe bağlı)"
            inputType = 2
            singleLine = true
        }
        root.addView(minutes, matchWidth())

        val add = Button(this).apply {
            text = "Hatırlatıcı oluştur"
            setOnClickListener {
                val title = titleInput.text.toString().trim().ifBlank { "Whiteout Survival kontrolü" }
                val h = hours.text.toString().toLongOrNull() ?: 0L
                val m = minutes.text.toString().toLongOrNull() ?: 0L
                val total = h * 60L + m
                if (total <= 0L || total > 60L * 24L * 30L) {
                    Toast.makeText(this@MainActivity, "1 dakika ile 30 gün arasında süre gir.", Toast.LENGTH_LONG).show()
                } else {
                    scheduleReminder(title, total)
                    titleInput.text.clear()
                    hours.text.clear()
                    minutes.text.clear()
                    Toast.makeText(this@MainActivity, "Hatırlatıcı ayarlandı.", Toast.LENGTH_SHORT).show()
                    refreshList()
                }
            }
        }
        root.addView(add, matchWidth())

        root.addView(TextView(this).apply {
            text = "Örnek hızlı hatırlatıcılar"
            textSize = 19f
            setPadding(0, 22, 0, 8)
            setTextColor(0xFF20352A.toInt())
        })
        val quick = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(quick, matchWidth())
        listOf(
            "Araştırma kontrolü" to 8L,
            "Birlik eğitimi kontrolü" to 6L,
            "Kaynak birliklerini kontrol et" to 4L,
            "Günlük görevleri kontrol et" to 24L
        ).forEach { (label, h) ->
            quick.addView(Button(this).apply {
                text = "$label • $h sa"
                setOnClickListener { scheduleReminder(label, h * 60L); refreshList() }
            }, matchWidth())
        }

        root.addView(TextView(this).apply {
            text = "Kurulu hatırlatıcılar"
            textSize = 19f
            setPadding(0, 22, 0, 8)
            setTextColor(0xFF20352A.toInt())
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, matchWidth())
        root.addView(Button(this).apply {
            text = "Tüm hatırlatıcıları temizle"
            setOnClickListener {
                val alarms = prefs.all.keys.toList()
                alarms.forEach { key ->
                    val id = key.toIntOrNull() ?: return@forEach
                    val pi = PendingIntent.getBroadcast(
                        this@MainActivity, id,
                        Intent(this@MainActivity, ReminderReceiver::class.java),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi)
                }
                prefs.edit().clear().apply()
                refreshList()
            }
        }, matchWidth())
        refreshList()
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("wos_reminders", "Gelişim hatırlatıcıları", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun scheduleReminder(title: String, minutes: Long) {
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val triggerAt = System.currentTimeMillis() + minutes * 60_000L
        prefs.edit().putString(id.toString(), "$title|$triggerAt").apply()
        val intent = Intent(this, ReminderReceiver::class.java).apply {
            putExtra("title", title)
            putExtra("id", id)
        }
        val pi = PendingIntent.getBroadcast(
            this, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            } catch (_: Exception) {}
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    private fun refreshList() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val now = System.currentTimeMillis()
        val fmt = SimpleDateFormat("dd MMM HH:mm", Locale("tr", "TR"))
        prefs.all.toSortedMap().forEach { (key, value) ->
            val id = key.toIntOrNull() ?: return@forEach
            val parts = (value as? String)?.split("|") ?: return@forEach
            if (parts.size < 2) return@forEach
            val time = parts[1].toLongOrNull() ?: return@forEach
            val label = parts[0]
            list.addView(TextView(this).apply {
                text = "• $label — ${if (time > now) fmt.format(Date(time)) else "zamanı geldi"}"
                textSize = 15f
                setPadding(0, 8, 0, 8)
            })
        }
        if (prefs.all.isEmpty()) list.addView(TextView(this).apply { text = "Henüz hatırlatıcı yok." })
    }
}
