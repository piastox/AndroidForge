package com.example.whiteouthelper

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Whiteout Survival kontrolü"
        val id = intent.getIntExtra("id", 1)
        val notification = NotificationCompat.Builder(context, "wos_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Whiteout Yardımcı")
            .setContentText("$title zamanı geldi.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$title zamanı geldi. Oyuna girip durumu kontrol edebilirsin."))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(id, notification)
        context.getSharedPreferences("timers", Context.MODE_PRIVATE).edit().remove(id.toString()).apply()
    }
}
